from django.contrib import admin

from .models import Board

admin.site.register(Board)
